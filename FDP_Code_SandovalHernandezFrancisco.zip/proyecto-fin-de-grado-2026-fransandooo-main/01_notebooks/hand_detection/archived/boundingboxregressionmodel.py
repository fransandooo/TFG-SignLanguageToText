# -*- coding: utf-8 -*-
"""Archived hand bounding-box regression exploration.

## Load Dataset
"""

import os, shutil, pathlib

# Root working dir inside Colab
PROJ_ROOT = "/content/hand_bbox_baseline"
DATA_ROOT = f"{PROJ_ROOT}/data"
RAW_ROOT  = f"{DATA_ROOT}/raw"          # where the original Kaggle files live (read-only for us)
WORK_ROOT = f"{DATA_ROOT}/work"         # where we'll convert/normalize annotations
os.makedirs(RAW_ROOT, exist_ok=True)
os.makedirs(WORK_ROOT, exist_ok=True)

for p in [PROJ_ROOT, DATA_ROOT, RAW_ROOT, WORK_ROOT]:
    print(p, "OK" if os.path.exists(p) else "MISSING")

!pip -q install kagglehub scipy matplotlib pillow

import kagglehub, os, shutil, glob

# 1) Download to KaggleHub cache; returns a directory
cache_path = kagglehub.dataset_download("armannikkhah/hand-dataset")
print("KaggleHub cache:", cache_path)

# 2) Copy everything from cache to our RAW_ROOT, but don't duplicate if already copied
def copytree(src, dst):
    src = os.path.abspath(src)
    dst = os.path.abspath(dst)
    for root, dirs, files in os.walk(src):
        rel = os.path.relpath(root, src)
        dest_dir = os.path.join(dst, rel) if rel != "." else dst
        os.makedirs(dest_dir, exist_ok=True)
        for f in files:
            src_f = os.path.join(root, f)
            dst_f = os.path.join(dest_dir, f)
            if not os.path.exists(dst_f):
                shutil.copy2(src_f, dst_f)

copytree(cache_path, RAW_ROOT)

# 3) Quick peek: list a few items
for path in glob.glob(os.path.join(RAW_ROOT, "*"))[:20]:
    print(path)

import os, glob, json, re
from collections import Counter

root = RAW_ROOT
all_files = [os.path.relpath(p, root) for p in glob.glob(os.path.join(root, "**"), recursive=True) if os.path.isfile(p)]
exts = Counter([os.path.splitext(f)[1].lower() for f in all_files])

print("Top-level files:")
for f in sorted([p for p in all_files if os.sep not in p])[:50]:
    print("  ", f)

print("\nExtensions frequency:", dict(exts))

# Check for common annotation containers
candidates = []
for pat in ["*.xml", "*.json", "*.csv", "*.txt"]:
    matches = glob.glob(os.path.join(root, "**", pat), recursive=True)
    if matches:
        candidates.append((pat, len(matches), matches[:5]))
print("\nPotential annotation files:")
for pat, n, sample in candidates:
    print(f"  {pat}: {n} files (sample: {[os.path.relpath(s, root) for s in sample]})")

import glob, os, xml.etree.ElementTree as ET

# Try to find the VOC root that contains Annotations and JPEGImages
VOC_ROOT = None
for root, dirs, files in os.walk(RAW_ROOT):
    if "Annotations" in dirs and "JPEGImages" in dirs:
        VOC_ROOT = os.path.join(root)
        break

print("VOC_ROOT:", VOC_ROOT)

# List a few example files
print("\nSome annotation files:")
for path in glob.glob(os.path.join(VOC_ROOT, "Annotations", "*.xml"))[:5]:
    print(" ", os.path.basename(path))

print("\nSome images:")
for path in glob.glob(os.path.join(VOC_ROOT, "JPEGImages", "*.jpg"))[:5]:
    print(" ", os.path.basename(path))

import os, xml.etree.ElementTree as ET
from pprint import pprint

sample_xml = os.path.join(VOC_ROOT, "Annotations", "010151_hand.xml")  # pick any name from the list you saw
tree = ET.parse(sample_xml)
root = tree.getroot()

# Pull a few top-level fields
img_filename = root.findtext("filename")
size_w = int(root.find("size/width").text)
size_h = int(root.find("size/height").text)

print("Image file:", img_filename)
print("Image size:", size_w, "x", size_h)

# Objects = annotated instances (hands)
objects = []
for obj in root.findall("object"):
    name = obj.findtext("name")
    bbox = obj.find("bndbox")
    xmin = int(float(bbox.findtext("xmin")))
    ymin = int(float(bbox.findtext("ymin")))
    xmax = int(float(bbox.findtext("xmax")))
    ymax = int(float(bbox.findtext("ymax")))
    # VOC is 1-based in some old tools; these files typically store 1-based ints.
    # We'll convert to 0-based later if needed; for now just inspect.
    objects.append({"name": name, "xmin": xmin, "ymin": ymin, "xmax": xmax, "ymax": ymax})

print("\nFound objects:")
pprint(objects)

import os
from PIL import Image, ImageDraw
import matplotlib.pyplot as plt

jpg_path = os.path.join(VOC_ROOT, "JPEGImages", img_filename)
im = Image.open(jpg_path).convert("RGB")
draw = ImageDraw.Draw(im)

for o in objects:
    # VOC boxes are inclusive; PIL rectangle is fine with these corners.
    draw.rectangle([(o["xmin"], o["ymin"]), (o["xmax"], o["ymax"])], outline=(255,0,0), width=3)
    draw.text((o["xmin"], max(0, o["ymin"]-12)), o["name"], fill=(255,0,0))

plt.figure(figsize=(6,6))
plt.imshow(im)
plt.axis("off")
plt.show()

import glob, csv

ann_dir = os.path.join(VOC_ROOT, "Annotations")
img_dir = os.path.join(VOC_ROOT, "JPEGImages")

rows = []
xml_files = sorted(glob.glob(os.path.join(ann_dir, "*.xml")))
print("XML files:", len(xml_files))

for xml_path in xml_files:
    root = ET.parse(xml_path).getroot()
    filename = root.findtext("filename")
    W = int(root.find("size/width").text)
    H = int(root.find("size/height").text)
    img_path = os.path.join(img_dir, filename)

    for obj in root.findall("object"):
        name = obj.findtext("name")
        bbox = obj.find("bndbox")
        xmin = int(float(bbox.findtext("xmin")))
        ymin = int(float(bbox.findtext("ymin")))
        xmax = int(float(bbox.findtext("xmax")))
        ymax = int(float(bbox.findtext("ymax")))

        # Clamp to image and ensure xmin<xmax, ymin<ymax
        xmin = max(0, min(xmin, W-1))
        xmax = max(0, min(xmax, W-1))
        ymin = max(0, min(ymin, H-1))
        ymax = max(0, min(ymax, H-1))
        if xmax <= xmin or ymax <= ymin:
            continue  # skip degenerate boxes

        rows.append([img_path, W, H, name, xmin, ymin, xmax, ymax])

print("Total hand instances:", len(rows))

# Save the per-instance CSV in WORK_ROOT
all_boxes_csv = os.path.join(WORK_ROOT, "hand_voc_instances.csv")
with open(all_boxes_csv, "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["image_path","width","height","class","xmin","ymin","xmax","ymax"])
    w.writerows(rows)

print("Wrote:", all_boxes_csv)

import pandas as pd

all_df = pd.read_csv(all_boxes_csv)
print("Instances:", len(all_df), " Unique images:", all_df["image_path"].nunique())

# Compute area and pick the largest box per image
all_df["area"] = (all_df["xmax"] - all_df["xmin"]) * (all_df["ymax"] - all_df["ymin"])
dominant = (all_df.sort_values("area", ascending=False)
                 .groupby("image_path", as_index=False)
                 .first()
                 .drop(columns=["area"]))

baseline_csv = os.path.join(WORK_ROOT, "hand_baseline_dominant_box.csv")
dominant.to_csv(baseline_csv, index=False)
print("Wrote:", baseline_csv, "with", len(dominant), "images")
dominant.head()

import pandas as pd, numpy as np, os
from PIL import Image, ImageDraw
import matplotlib.pyplot as plt
from math import ceil

baseline_csv = "/content/hand_bbox_baseline/data/work/hand_baseline_dominant_box.csv"
df = pd.read_csv(baseline_csv)

# sample a few
np.random.seed(42)
sample = df.sample(12).reset_index(drop=True)

# draw
cols = 4
rows = ceil(len(sample)/cols)
plt.figure(figsize=(cols*4, rows*4))

for i, row in sample.iterrows():
    img = Image.open(row["image_path"]).convert("RGB")
    draw = ImageDraw.Draw(img)
    draw.rectangle([(row["xmin"], row["ymin"]), (row["xmax"], row["ymax"])], outline=(255,0,0), width=3)
    plt.subplot(rows, cols, i+1)
    plt.imshow(img)
    plt.title(os.path.basename(row["image_path"]))
    plt.axis("off")

plt.tight_layout()
plt.show()

"""## Own CNN Model using Keras Model"""

import pandas as pd, numpy as np, os

work = "/content/hand_bbox_baseline/data/work"
df = pd.read_csv(os.path.join(work, "hand_baseline_dominant_box.csv"))

# Normalize here to keep the tf.data mapper simpler
df["tx"] = df["xmin"] / df["width"]
df["ty"] = df["ymin"] / df["height"]
df["bx"] = df["xmax"] / df["width"]
df["by"] = df["ymax"] / df["height"]

# Basic sanity: keep within [0,1]
for c in ["tx","ty","bx","by"]:
    df[c] = df[c].clip(0, 1)

# Split (stratification isn’t needed: single class)
np.random.seed(123)
perm = np.random.permutation(len(df))
val_ratio = 0.15
val_n = int(len(df)*val_ratio)
val_idx = set(perm[:val_n])

df["split"] = ["val" if i in val_idx else "train" for i in range(len(df))]
train_df = df[df["split"]=="train"].copy()
val_df   = df[df["split"]=="val"].copy()

train_csv = os.path.join(work, "train_baseline.csv")
val_csv   = os.path.join(work, "val_baseline.csv")
train_df.to_csv(train_csv, index=False)
val_df.to_csv(val_csv, index=False)

print("Train:", len(train_df), " Val:", len(val_df))
print("Saved:\n ", train_csv, "\n ", val_csv)
train_df.head(2), val_df.head(2)

import tensorflow as tf
import pandas as pd

IMG_SIZE = 224
BATCH = 16
AUTOTUNE = tf.data.AUTOTUNE

work = "/content/hand_bbox_baseline/data/work"
train_csv = f"{work}/train_baseline.csv"
val_csv   = f"{work}/val_baseline.csv"

train_df = pd.read_csv(train_csv)
val_df   = pd.read_csv(val_csv)

def make_ds(df, shuffle=True, repeat=False):
    paths = df["image_path"].values
    labels = df[["tx","ty","bx","by"]].values.astype("float32")

    ds = tf.data.Dataset.from_tensor_slices((paths, labels))

    def _load(path, y):
        img = tf.io.read_file(path)
        img = tf.io.decode_jpeg(img, channels=3)
        img = tf.image.resize(img, (IMG_SIZE, IMG_SIZE))
        img = tf.cast(img, tf.float32) / 255.0
        return img, y

    ds = ds.map(_load, num_parallel_calls=AUTOTUNE)
    if shuffle:
        ds = ds.shuffle(1024)
    if repeat:
        ds = ds.repeat()
    ds = ds.batch(BATCH).prefetch(AUTOTUNE)
    return ds

train_ds = make_ds(train_df, shuffle=True,  repeat=True)   # infinite for training
val_ds   = make_ds(val_df,   shuffle=False, repeat=False)  # one pass for validation

# Peek one batch to confirm shapes
imgs, ys = next(iter(train_ds))
print("Batch images:", imgs.shape, " Batch labels:", ys.shape, " (expect [B,224,224,3] and [B,4])")

"""Step 7 — Define the model + IoU metric (TensorFlow/Keras)"""

import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers

IMG_SIZE = 224

def iou_metric(y_true, y_pred):
    # y_*: [B,4] with normalized [tx,ty,bx,by]
    # ensure valid ordering and clip to [0,1]
    y_true = tf.clip_by_value(y_true, 0.0, 1.0)
    y_pred = tf.clip_by_value(y_pred, 0.0, 1.0)

    # (tx,ty) is top-left; (bx,by) is bottom-right
    xA = tf.maximum(y_true[:,0], y_pred[:,0])
    yA = tf.maximum(y_true[:,1], y_pred[:,1])
    xB = tf.minimum(y_true[:,2], y_pred[:,2])
    yB = tf.minimum(y_true[:,3], y_pred[:,3])

    interW = tf.maximum(0.0, xB - xA)
    interH = tf.maximum(0.0, yB - yA)
    inter  = interW * interH

    area_true = tf.maximum(0.0, (y_true[:,2]-y_true[:,0])) * tf.maximum(0.0, (y_true[:,3]-y_true[:,1]))
    area_pred = tf.maximum(0.0, (y_pred[:,2]-y_pred[:,0])) * tf.maximum(0.0, (y_pred[:,3]-y_pred[:,1]))
    union = area_true + area_pred - inter + 1e-7

    iou = inter / union
    return tf.reduce_mean(iou)

def make_baseline_model():
    inputs = keras.Input(shape=(IMG_SIZE, IMG_SIZE, 3))
    x = inputs

    def block(x, f, s=1):
        x = layers.Conv2D(f, 3, strides=s, padding="same", use_bias=False)(x)
        x = layers.BatchNormalization()(x)
        x = layers.ReLU()(x)
        return x

    x = block(x, 32, s=2)   # 112x112
    x = block(x, 32)
    x = block(x, 64, s=2)   # 56x56
    x = block(x, 64)
    x = block(x, 128, s=2)  # 28x28
    x = block(x, 128)
    x = block(x, 256, s=2)  # 14x14
    x = block(x, 256)

    x = layers.GlobalAveragePooling2D()(x)
    x = layers.Dropout(0.25)(x)
    x = layers.Dense(128, activation="relu")(x)
    outputs = layers.Dense(4, activation="linear")(x)  # normalized coords, no sigmoid (let loss handle it)

    model = keras.Model(inputs, outputs, name="hand_bbox_baseline_cnn")
    model.compile(
        optimizer=keras.optimizers.Adam(learning_rate=1e-3),
        loss=keras.losses.Huber(delta=1.0),
        metrics=[iou_metric]
    )
    return model

baseline_model = make_baseline_model()
baseline_model.summary()

"""Step 8 — Train a few epochs"""

import math

EPOCHS = 15
STEPS_PER_EPOCH = math.ceil(371 / 16)  # train size / batch
VAL_STEPS = math.ceil(65 / 16)

callbacks = [
    tf.keras.callbacks.EarlyStopping(monitor="val_iou_metric", patience=5, mode="max", restore_best_weights=True),
    tf.keras.callbacks.ReduceLROnPlateau(monitor="val_iou_metric", mode="max", factor=0.5, patience=2, min_lr=1e-5, verbose=1)
]

history = baseline_model.fit(
    train_ds,
    epochs=EPOCHS,
    steps_per_epoch=STEPS_PER_EPOCH,
    validation_data=val_ds,
    validation_steps=VAL_STEPS,
    callbacks=callbacks,
    verbose=1,
)

"""Step 9 — Qualitative check: visualize predictions on validation images"""

import pandas as pd, numpy as np, os
from PIL import Image, ImageDraw
import matplotlib.pyplot as plt

work = "/content/hand_bbox_baseline/data/work"
val_df = pd.read_csv(f"{work}/val_baseline.csv")

def preprocess_for_model(path):
    img = tf.io.read_file(path)
    img = tf.io.decode_jpeg(img, channels=3)
    img = tf.image.resize(img, (IMG_SIZE, IMG_SIZE))
    img = tf.cast(img, tf.float32) / 255.0
    return img

# sample a few validation images
np.random.seed(7)
vis = val_df.sample(8).reset_index(drop=True)

# Build input batch
batch_imgs = tf.stack([preprocess_for_model(p) for p in vis["image_path"].values], axis=0)
preds = baseline_model.predict(batch_imgs, verbose=0)  # [N,4] normalized

# Plot
cols = 4
rows = int(np.ceil(len(vis)/cols))
plt.figure(figsize=(cols*4, rows*4))

for i, row in vis.iterrows():
    img = Image.open(row["image_path"]).convert("RGB")
    W, H = row["width"], row["height"]

    # GT denorm
    gt = (
        row["tx"]*W, row["ty"]*H,
        row["bx"]*W, row["by"]*H
    )

    # Pred denorm
    pr = preds[i]
    pr = np.clip(pr, 0, 1)
    pr = (pr[0]*W, pr[1]*H, pr[2]*W, pr[3]*H)

    draw = ImageDraw.Draw(img)
    # GT = green, Pred = red
    draw.rectangle([(gt[0], gt[1]), (gt[2], gt[3])], outline=(0,255,0), width=3)
    draw.rectangle([(pr[0], pr[1]), (pr[2], pr[3])], outline=(255,0,0), width=3)

    plt.subplot(rows, cols, i+1)
    plt.imshow(img)
    plt.title(os.path.basename(row["image_path"]))
    plt.axis("off")

plt.tight_layout()
plt.show()

"""The model I created above is not bad, but is a better aproach to use a pretrained model and finetune it for our purpose in our case wer are going to use the MobileNetv2

## Fine Tunning MobileNetV2

Step 10 — Build a MobileNetV2 regressor (frozen backbone)
"""

import pandas as pd, os, numpy as np

work = "/content/hand_bbox_baseline/data/work"
all_csv = f"{work}/hand_voc_instances.csv"         # per-instance CSV we created earlier

df_all = pd.read_csv(all_csv)
counts = df_all.groupby("image_path").size().rename("num_hands")
onehand = (counts == 1)
print("Images total:", counts.shape[0], " | single-hand images:", onehand.sum())

# keep only those images
df1 = (df_all.merge(counts, left_on="image_path", right_index=True)
              .query("num_hands == 1")
              .drop(columns=["num_hands"])
              .copy())

# rename to the baseline format and compute normalized coords
df1["tx"] = df1["xmin"] / df1["width"]
df1["ty"] = df1["ymin"] / df1["height"]
df1["bx"] = df1["xmax"] / df1["width"]
df1["by"] = df1["ymax"] / df1["height"]
for c in ["tx","ty","bx","by"]:
    df1[c] = df1[c].clip(0,1)

# split
np.random.seed(123)
idx = np.random.permutation(len(df1))
val_n = max(1, int(0.15*len(df1)))
val_idx = set(idx[:val_n])
df1["split"] = ["val" if i in val_idx else "train" for i in range(len(df1))]

train1 = df1[df1["split"]=="train"].copy()
val1   = df1[df1["split"]=="val"].copy()

train_csv_1 = f"{work}/train_singlehand.csv"
val_csv_1   = f"{work}/val_singlehand.csv"
train1.to_csv(train_csv_1, index=False)
val1.to_csv(val_csv_1, index=False)

print("Train single-hand:", len(train1), " Val:", len(val1))

import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers

def to_corners(params):
    # params: [B,4] = cx, cy, w, h (all normalized)
    cx, cy, w, h = tf.split(params, 4, axis=-1)
    # clip so widths/heights don’t exceed image (1.0)
    w = tf.clip_by_value(w, 1e-6, 1.0)
    h = tf.clip_by_value(h, 1e-6, 1.0)
    tx = tf.clip_by_value(cx - w/2.0, 0.0, 1.0)
    ty = tf.clip_by_value(cy - h/2.0, 0.0, 1.0)
    bx = tf.clip_by_value(cx + w/2.0, 0.0, 1.0)
    by = tf.clip_by_value(cy + h/2.0, 0.0, 1.0)
    return tf.concat([tx,ty,bx,by], axis=-1)

def iou_metric(y_true, y_pred):
    y_true = tf.clip_by_value(y_true, 0.0, 1.0)
    y_pred = tf.clip_by_value(y_pred, 0.0, 1.0)
    xA = tf.maximum(y_true[:,0], y_pred[:,0]); yA = tf.maximum(y_true[:,1], y_pred[:,1])
    xB = tf.minimum(y_true[:,2], y_pred[:,2]); yB = tf.minimum(y_true[:,3], y_pred[:,3])
    inter = tf.maximum(0.0, xB-xA) * tf.maximum(0.0, yB-yA)
    area_t = tf.maximum(0.0, y_true[:,2]-y_true[:,0]) * tf.maximum(0.0, y_true[:,3]-y_true[:,1])
    area_p = tf.maximum(0.0, y_pred[:,2]-y_pred[:,0]) * tf.maximum(0.0, y_pred[:,3]-y_pred[:,1])
    union = area_t + area_p - inter + 1e-7
    return tf.reduce_mean(inter / union)

def iou_loss(y_true, y_pred):
    return 1.0 - iou_metric(y_true, y_pred)

def build_mnv2_center_size(tail_layers=0, base_lr=2e-4, wd=1e-5):
    inputs = keras.Input(shape=(224,224,3))
    x = layers.Lambda(lambda t: (t*2.0) - 1.0)(inputs)

    base = keras.applications.MobileNetV2(include_top=False, weights="imagenet", input_shape=(224,224,3))
    base.trainable = False
    if tail_layers > 0:
        for layer in base.layers[-tail_layers:]:
            if not isinstance(layer, layers.BatchNormalization):
                layer.trainable = True

    x = base(x)
    x = layers.GlobalAveragePooling2D()(x)
    x = layers.Dropout(0.25)(x)
    x = layers.Dense(128, activation="relu", kernel_regularizer=keras.regularizers.l2(wd))(x)

    # Predict center (sigmoid) and size (softplus)
    cx_cy = layers.Dense(2, activation="sigmoid")(x)
    wh_raw = layers.Dense(2, activation="linear")(x)
    wh = layers.Activation(lambda t: tf.nn.softplus(t))(wh_raw)  # positive

    params = layers.Concatenate()([cx_cy, wh])        # (cx, cy, w, h)
    corners = layers.Lambda(to_corners)(params)       # (tx, ty, bx, by) in [0,1]

    model = keras.Model(inputs, corners, name="mnv2_center_size")

    huber = keras.losses.Huber(delta=1.0)
    def combo_loss(y_true, y_pred):
        return 0.5 * huber(y_true, y_pred) + 0.5 * iou_loss(y_true, y_pred)

    model.compile(optimizer=keras.optimizers.Adam(base_lr),
                  loss=combo_loss,
                  metrics=[iou_metric])
    return model

mnv2_cs = build_mnv2_center_size(tail_layers=0, base_lr=2e-4)
mnv2_cs.summary()

"""Step 11 — Train the frozen-backbone model"""

import math, tensorflow as tf
from tensorflow import keras

EPOCHS = 40
STEPS_PER_EPOCH = int(tf.math.ceil(371 / 16))
VAL_STEPS = int(tf.math.ceil(65 / 16))

callbacks = [
    keras.callbacks.EarlyStopping(monitor="val_iou_metric", patience=6, mode="max", restore_best_weights=True),
    keras.callbacks.ReduceLROnPlateau(monitor="val_iou_metric", mode="max", factor=0.5, patience=3, min_lr=1e-5, verbose=1),
]

history_frozen = mnv2_cs.fit(
    train_ds, validation_data=val_ds,
    epochs=EPOCHS,
    steps_per_epoch=STEPS_PER_EPOCH,
    validation_steps=VAL_STEPS,
    callbacks=callbacks, verbose=1
)

"""Step 12 — Fine-tune the last layers of the backbone (optional but recommended)"""

# Rebuild same architecture with tail unfreezing
mnv2_cs_ft = build_mnv2_center_size(tail_layers=32, base_lr=1e-4)
mnv2_cs_ft.set_weights(mnv2_cs.get_weights())  # transfer learned head

callbacks_ft = [
    keras.callbacks.EarlyStopping(monitor="val_iou_metric", patience=4, mode="max", restore_best_weights=True),
    keras.callbacks.ReduceLROnPlateau(monitor="val_iou_metric", mode="max", factor=0.5, patience=2, min_lr=1e-5, verbose=1),
]

history_ft = mnv2_cs_ft.fit(
    train_ds, validation_data=val_ds,
    epochs=20,
    steps_per_epoch=STEPS_PER_EPOCH,
    validation_steps=VAL_STEPS,
    callbacks=callbacks_ft, verbose=1
)

"""Evaluate properly (numbers + pictures)"""

import numpy as np, pandas as pd

def iou_numpy(y_true, y_pred):
    y_true = np.clip(y_true, 0, 1); y_pred = np.clip(y_pred, 0, 1)
    xA = np.maximum(y_true[:,0], y_pred[:,0]); yA = np.maximum(y_true[:,1], y_pred[:,1])
    xB = np.minimum(y_true[:,2], y_pred[:,2]); yB = np.minimum(y_true[:,3], y_pred[:,3])
    inter = np.maximum(0, xB-xA) * np.maximum(0, yB-yA)
    area_t = np.maximum(0, y_true[:,2]-y_true[:,0]) * np.maximum(0, y_true[:,3]-y_true[:,1])
    area_p = np.maximum(0, y_pred[:,2]-y_pred[:,0]) * np.maximum(0, y_pred[:,3]-y_pred[:,1])
    union = area_t + area_p - inter + 1e-7
    return inter / union

# build a val batch and predict
val_df = pd.read_csv("/content/hand_bbox_baseline/data/work/val_baseline.csv")
import tensorflow as tf
def preprocess(path):
    img = tf.io.read_file(path); img = tf.io.decode_jpeg(img,3)
    img = tf.image.resize(img, (224,224)); img = tf.cast(img, tf.float32)/255.0
    return img
batch = tf.stack([preprocess(p) for p in val_df["image_path"].values], axis=0)
preds = mnv2_cs_ft.predict(batch, verbose=0)  # corners in [0,1]
gts = val_df[["tx","ty","bx","by"]].values.astype("float32")
ious = iou_numpy(gts, preds)
print("mIoU:", ious.mean(), "  IoU>=0.5 rate:", (ious>=0.5).mean())

import pandas as pd, numpy as np, os
from PIL import Image, ImageDraw
import matplotlib.pyplot as plt

work = "/content/hand_bbox_baseline/data/work"
val_df = pd.read_csv(f"{work}/val_baseline.csv")

def preprocess_for_model(path):
    img = tf.io.read_file(path)
    img = tf.io.decode_jpeg(img, channels=3)
    img = tf.image.resize(img, (IMG_SIZE, IMG_SIZE))
    img = tf.cast(img, tf.float32) / 255.0
    return img

# sample a few validation images
np.random.seed(7)
vis = val_df.sample(8).reset_index(drop=True)

# Build input batch
batch_imgs = tf.stack([preprocess_for_model(p) for p in vis["image_path"].values], axis=0)
preds = mnv2_cs_ft.predict(batch_imgs, verbose=0)  # [N,4] normalized

# Plot
cols = 4
rows = int(np.ceil(len(vis)/cols))
plt.figure(figsize=(cols*4, rows*4))

for i, row in vis.iterrows():
    img = Image.open(row["image_path"]).convert("RGB")
    W, H = row["width"], row["height"]

    # GT denorm
    gt = (
        row["tx"]*W, row["ty"]*H,
        row["bx"]*W, row["by"]*H
    )

    # Pred denorm
    pr = preds[i]
    pr = np.clip(pr, 0, 1)
    pr = (pr[0]*W, pr[1]*H, pr[2]*W, pr[3]*H)

    draw = ImageDraw.Draw(img)
    # GT = green, Pred = red
    draw.rectangle([(gt[0], gt[1]), (gt[2], gt[3])], outline=(0,255,0), width=3)
    draw.rectangle([(pr[0], pr[1]), (pr[2], pr[3])], outline=(255,0,0), width=3)

    plt.subplot(rows, cols, i+1)
    plt.imshow(img)
    plt.title(os.path.basename(row["image_path"]))
    plt.axis("off")

plt.tight_layout()
plt.show()

"""# Model FineTunning V2 Yolov8-nano"""

from pathlib import Path
from glob import glob
import os, shutil, xml.etree.ElementTree as ET

PROJ = Path("/content/hand_bbox_detector")
DATA = PROJ / "data"
YOLO_DATA_DIR = DATA / "yolo"         # where YOLO-format labels/images will live
RAW_VOC = Path("/content/hand_bbox_baseline/data/raw/hand_dataset/evaluation_code/VOC2007/VOCdevkit/VOC2007")  # from your previous section

for p in [PROJ, DATA, YOLO_DATA_DIR]:
    p.mkdir(parents=True, exist_ok=True)

print("VOC root:", RAW_VOC)
print("Exists:", RAW_VOC.exists())


!pip -q install ultralytics==8.1.0
!pip install --upgrade ultralytics

# The import of ultralytics.YOLO here was causing the name collision with the Path object.
# By renaming YOLO to YOLO_DATA_DIR, we avoid this conflict.
from ultralytics import YOLO
import torch

"""## Convert Pascal-VOC → YOLO labels"""

import random, math

voc_images = RAW_VOC / "JPEGImages"
voc_anns   = RAW_VOC / "Annotations"
voc_sets   = RAW_VOC / "ImageSets" / "Main"

# Try to read official splits if they exist
def read_split_list(fname):
    f = voc_sets / fname
    if not f.exists(): return None
    ids = [line.strip() for line in open(f) if line.strip()]
    return [f"{i}.jpg" if i.endswith(".jpg")==False else i for i in ids]

train_ids = read_split_list("hand_train_big.txt")
test_ids  = read_split_list("hand_test_big.txt")
val_ids   = read_split_list("hand_val_big.txt")

all_imgs = sorted([os.path.basename(p) for p in glob(str(voc_images/"*.jpg"))])

if train_ids is None:
    # fallback: random split 80/20
    random.seed(42)
    random.shuffle(all_imgs)
    split = int(0.8 * len(all_imgs))
    train_ids = all_imgs[:split]
    val_ids   = all_imgs[split:]
else:
    # If there is only train/test, use test as val
    if val_ids is None:
        val_ids = test_ids if test_ids is not None else []

print("Train:", len(train_ids), " Val:", len(val_ids))

# Create YOLO dirs
for sub in ["images/train","images/val","labels/train","labels/val"]:
    (YOLO_DATA_DIR / sub).mkdir(parents=True, exist_ok=True)

# helper: VOC XML -> YOLO txt
def voc_to_yolo(xmin,ymin,xmax,ymax,W,H):
    cx = (xmin+xmax)/2.0 / W
    cy = (ymin+ymax)/2.0 / H
    w  = (xmax-xmin) / W
    h  = (ymax-ymin) / H
    return max(0,min(1,cx)), max(0,min(1,cy)), max(0,min(1,w)), max(0,min(1,h))

# Convert a set
def convert_split(id_list, split):
    for img_name in id_list:
        img_path = voc_images / img_name
        xml_path = voc_anns / (os.path.splitext(img_name)[0] + ".xml")
        if not img_path.exists() or not xml_path.exists():
            continue

        # copy image
        out_img = YOLO_DATA_DIR / "images" / split / img_name
        if not out_img.exists():
            shutil.copy2(img_path, out_img)

        # parse xml -> label txt
        root = ET.parse(xml_path).getroot()
        W = int(root.find("size/width").text)
        H = int(root.find("size/height").text)

        lines = []
        for obj in root.findall("object"):
            name = obj.findtext("name").strip().lower()
            if name != "hand":  # single class
                continue
            b = obj.find("bndbox")
            xmin = int(float(b.findtext("xmin"))); ymin = int(float(b.findtext("ymin")))
            xmax = int(float(b.findtext("xmax"))); ymax = int(float(b.findtext("ymax")))
            # clamp
            xmin = max(0, min(xmin, W-1)); xmax = max(0, min(xmax, W-1))
            ymin = max(0, min(ymin, H-1)); ymax = max(0, min(ymax, H-1))
            if xmax <= xmin or ymax <= ymin:
                continue
            cx,cy,w,h = voc_to_yolo(xmin,ymin,xmax,ymax,W,H)
            lines.append(f"0 {cx:.6f} {cy:.6f} {w:.6f} {h:.6f}")

        out_lbl = YOLO_DATA_DIR / "labels" / split / (os.path.splitext(img_name)[0] + ".txt")
        with open(out_lbl, "w") as f:
            f.write("\n".join(lines))

convert_split(train_ids, "train")
convert_split(val_ids,   "val")

print("Done. Example label file with first non-empty:")
import itertools
for p in itertools.chain(glob(str((YOLO_DATA_DIR/"labels/train")/"*.txt")),
                         glob(str((YOLO_DATA_DIR/"labels/val")/"*.txt"))):
    if os.path.getsize(p) > 0:
        print(p); print(open(p).read()); break

"""## Create the Yolo data.yml"""

yaml_text = f"""
path: {YOLO_DATA_DIR}
train: images/train
val: images/val
names:
  0: hand
"""
(DATA / "hand_data.yaml").write_text(yaml_text)
print((DATA / "hand_data.yaml").read_text())

"""## Train YOLOv8-nano (multi-hand)

#### Normal Yolov8nano
"""

from ultralytics import YOLO
import torch  # Add this import

# Create a fresh model (nano)
model = YOLO("yolov8n.pt")   # pretrained COCO weights

# Train
results = model.train(
    data=str(DATA/"hand_data.yaml"),
    imgsz=512,
    epochs=50,
    batch=16,
    lr0=0.01,
    device=0 if torch.cuda.is_available() else 'cpu',  # Changed this line
    patience=10,          # early stopping on val metrics
    optimizer="SGD",      # or "AdamW"
    name="yolov8n_hands",
    project=str(PROJ/"runs")
)

"""#### Yolov8nano fine tuned best weights at higher resolution"""

from ultralytics import YOLO
model = YOLO("/content/hand_bbox_detector/runs/yolov8n_hands2/weights/best.pt")

results = model.train(
    data=str(DATA/"hand_data.yaml"),
    imgsz=640,           # ↑ from 512
    epochs=30,
    batch=12,            # reduce if you hit OOM; try 16 first
    lr0=0.005,           # slightly lower LR for fine-tune
    device=0,
    patience=10,
    optimizer="SGD",
    name="yolov8n_hands_ft640",
    project=str(PROJ/"runs")
)

"""#### Normal Yolov8small (Bigger Model)"""

from ultralytics import YOLO
model = YOLO("yolov8s.pt")  # larger than nano

results = model.train(
    data=str(DATA/"hand_data.yaml"),
    imgsz=640,
    epochs=50,
    batch=8,              # s uses more memory
    lr0=0.01,
    device=0,
    patience=12,
    optimizer="SGD",
    name="yolov8s_hands_640",
    project=str(PROJ/"runs")
)

"""#### Test mBest model"""

best = YOLO(str(PROJ/"runs"/"yolov8s_hands_640"/"weights"/"best.pt"))

# Evaluate on val set (reports Precision/Recall/mAP)
metrics = best.val(data=str(DATA/"hand_data.yaml"), imgsz=512)
print("mAP@0.5:", metrics.box.map50, "  mAP@0.5:0.95:", metrics.box.map)

# Visualize a few predictions
pred = best.predict(
    source=str(YOLO_DATA_DIR/"images/val"),
    imgsz=512,
    conf=0.35,   # was default 0.25
    iou=0.45,    # NMS IOU (default 0.7); lower merges less, reduces spurious overlaps
    save=True, max_det=20
)
print("Saved to:", pred[0].save_dir)

"""#### Personal Photo Test"""

from google.colab import files
uploaded = files.upload()  # pick a local JPG/PNG with your hand visible
img_path = list(uploaded.keys())[0]
img_path

from ultralytics import YOLO
best = YOLO(str(PROJ/"runs"/"yolov8s_hands_640"/"weights"/"best.pt"))

res = best.predict(
    source=img_path,
    imgsz=640,     # you can try 512 or 640
    conf=0.35,     # try 0.35–0.5 if you see FPs
    iou=0.45,      # NMS IoU
    save=True
)
res[0]

import matplotlib.pyplot as plt
import numpy as np

r = res[0]                     # first (and only) image result
annot = r.plot()               # returns a BGR numpy image with boxes+labels
plt.imshow(annot[..., ::-1])   # convert BGR->RGB for matplotlib
plt.axis("off")
