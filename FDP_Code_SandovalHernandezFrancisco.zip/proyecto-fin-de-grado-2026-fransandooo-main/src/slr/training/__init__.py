"""Training loop and callbacks."""
