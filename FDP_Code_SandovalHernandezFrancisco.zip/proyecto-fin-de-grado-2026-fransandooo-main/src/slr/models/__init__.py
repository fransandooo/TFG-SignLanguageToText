"""Model definitions and registry."""
